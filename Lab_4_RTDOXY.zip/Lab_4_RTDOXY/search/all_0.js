var searchData=
[
  ['amplitude_0',['AMPLITUDE',['../_lab__4___r_t_final_8ino.html#ae2d3a48fb01bbc0fe795724379434d05',1,'Lab_4_RTFinal.ino']]]
];
