var searchData=
[
  ['taskfollowx_0',['TaskFollowX',['../_project_main_8ino_8ino.html#ad2ce339df2aa6395efdc21729d77aab8',1,'ProjectMain.ino.ino']]],
  ['taskreadjoystick_1',['TaskReadJoystick',['../_project_main_8ino_8ino.html#af113952b582b3984bcce73b76d04f19a',1,'ProjectMain.ino.ino']]],
  ['taskservoy_2',['TaskServoY',['../_project_main_8ino_8ino.html#a887571a4434dba7cbc5e1dc353ce0242',1,'ProjectMain.ino.ino']]],
  ['translateir_3',['translateIR',['../_project_main_8ino_8ino.html#a19ffc1c502ebb7a6838ee653c999e7ce',1,'ProjectMain.ino.ino']]]
];
