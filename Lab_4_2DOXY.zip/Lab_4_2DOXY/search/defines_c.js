var searchData=
[
  ['rawbuf_0',['RAWBUF',['../_i_rremote_8h.html#abb919079668bcc14433d4c857ab8a196',1,'IRremote.h']]],
  ['rc5_1',['RC5',['../_i_rremote_8h.html#a91697bfec209fb3146fde1f40e425ede',1,'IRremote.h']]],
  ['rc5_5frpt_5flength_2',['RC5_RPT_LENGTH',['../_i_rremote_int_8h.html#aa8c287a3a1602657fde8f7bc6741bf1f',1,'IRremoteInt.h']]],
  ['rc5_5ft1_3',['RC5_T1',['../_i_rremote_int_8h.html#aacadad5996114b73e6ebe4ac4a3670f8',1,'IRremoteInt.h']]],
  ['rc6_4',['RC6',['../_i_rremote_8h.html#a259ca3c51823b7454fb93db646b81bb1',1,'IRremote.h']]],
  ['rc6_5fhdr_5fmark_5',['RC6_HDR_MARK',['../_i_rremote_int_8h.html#aaf18416e602d4df98ade887edd350ae7',1,'IRremoteInt.h']]],
  ['rc6_5fhdr_5fspace_6',['RC6_HDR_SPACE',['../_i_rremote_int_8h.html#a1f9724085ece5ed0103b5ce5e57b7aff',1,'IRremoteInt.h']]],
  ['rc6_5frpt_5flength_7',['RC6_RPT_LENGTH',['../_i_rremote_int_8h.html#ab20744e40f55c70de7fd11c163643d03',1,'IRremoteInt.h']]],
  ['rc6_5ft1_8',['RC6_T1',['../_i_rremote_int_8h.html#a6c695681ce7b028d11ae6af423b96178',1,'IRremoteInt.h']]],
  ['repeat_9',['REPEAT',['../_i_rremote_8h.html#a2c9384c67919c632913b8db2088f8341',1,'IRremote.h']]]
];
