var searchData=
[
  ['panasonicaddress_0',['panasonicAddress',['../classdecode__results.html#a6f8f451468ba9e3cc8647799eb9ec23d',1,'decode_results']]],
  ['previous_1',['previous',['../_project_main_8ino_8ino.html#aa6680aad30971bdc23b341c2b6ee59eb',1,'ProjectMain.ino.ino']]]
];
