var searchData=
[
  ['unknown_0',['UNKNOWN',['../_i_rremote_8h.html#ac1ae4add974b9cfc6b5aaf8a578f01ab',1,'IRremote.h']]],
  ['usecpertick_1',['USECPERTICK',['../_i_rremote_8h.html#aad2fcaac88c28bf54ecbd42146a56e3f',1,'IRremote.h']]],
  ['utol_2',['UTOL',['../_i_rremote_int_8h.html#ad3a18e82bb4b51badb0727fce56a7557',1,'IRremoteInt.h']]]
];
