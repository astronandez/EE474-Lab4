var searchData=
[
  ['in1_5fpin_0',['IN1_PIN',['../_project_main_8ino_8ino.html#ae6efc05cbbe93f86a2c495adadefba18',1,'ProjectMain.ino.ino']]],
  ['in2_5fpin_1',['IN2_PIN',['../_project_main_8ino_8ino.html#aaa7c2af8811ab06c6c58108a0c757b71',1,'ProjectMain.ino.ino']]],
  ['in3_5fpin_2',['IN3_PIN',['../_project_main_8ino_8ino.html#a8b6ed01201232f35af14493fdaa338fd',1,'ProjectMain.ino.ino']]],
  ['in4_5fpin_3',['IN4_PIN',['../_project_main_8ino_8ino.html#ac208f374147f197eea7873d925a0f5e4',1,'ProjectMain.ino.ino']]],
  ['ir_5fuse_5ftimer2_4',['IR_USE_TIMER2',['../_i_rremote_int_8h.html#a318b99f761283ca3b5d483269cf99217',1,'IRremoteInt.h']]],
  ['irmessage_5',['IRmessage',['../_project_main_8ino_8ino.html#a60dd297f3e7867b920a5dc5dd743e324',1,'ProjectMain.ino.ino']]],
  ['irparams_6',['irparams',['../_i_rremote_int_8h.html#a5620be27a7445f25d43dbe3432ed6fd1',1,'IRremoteInt.h']]],
  ['irparams_5ft_7',['irparams_t',['../structirparams__t.html',1,'']]],
  ['irrecv_8',['IRrecv',['../class_i_rrecv.html',1,'IRrecv'],['../class_i_rrecv.html#a7f8c58a1fd314b6138936bb0a25e472b',1,'IRrecv::IRrecv()']]],
  ['irrecv_9',['irrecv',['../_project_main_8ino_8ino.html#a84028531ed04b53428dc49192477e313',1,'ProjectMain.ino.ino']]],
  ['irremote_2eh_10',['IRremote.h',['../_i_rremote_8h.html',1,'']]],
  ['irremoteint_2eh_11',['IRremoteInt.h',['../_i_rremote_int_8h.html',1,'']]],
  ['irsend_12',['IRsend',['../class_i_rsend.html',1,'IRsend'],['../class_i_rsend.html#a047d9e3f47864869afaa5076579c9f63',1,'IRsend::IRsend()']]]
];
