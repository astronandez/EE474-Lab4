var searchData=
[
  ['in1_5fpin_0',['IN1_PIN',['../_project_main_8ino_8ino.html#ae6efc05cbbe93f86a2c495adadefba18',1,'ProjectMain.ino.ino']]],
  ['in2_5fpin_1',['IN2_PIN',['../_project_main_8ino_8ino.html#aaa7c2af8811ab06c6c58108a0c757b71',1,'ProjectMain.ino.ino']]],
  ['in3_5fpin_2',['IN3_PIN',['../_project_main_8ino_8ino.html#a8b6ed01201232f35af14493fdaa338fd',1,'ProjectMain.ino.ino']]],
  ['in4_5fpin_3',['IN4_PIN',['../_project_main_8ino_8ino.html#ac208f374147f197eea7873d925a0f5e4',1,'ProjectMain.ino.ino']]],
  ['ir_5fuse_5ftimer2_4',['IR_USE_TIMER2',['../_i_rremote_int_8h.html#a318b99f761283ca3b5d483269cf99217',1,'IRremoteInt.h']]]
];
