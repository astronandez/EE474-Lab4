var searchData=
[
  ['jvc_0',['JVC',['../_i_rremote_8h.html#a10a30f916d697884c6ecad5b085a9c21',1,'IRremote.h']]],
  ['jvc_5fbit_5fmark_1',['JVC_BIT_MARK',['../_i_rremote_int_8h.html#a3eb74f5b177f68386ff35bd41e09a33c',1,'IRremoteInt.h']]],
  ['jvc_5fbits_2',['JVC_BITS',['../_i_rremote_int_8h.html#afcb4f4e6144a1e3c779b2b8777b8f8ac',1,'IRremoteInt.h']]],
  ['jvc_5fhdr_5fmark_3',['JVC_HDR_MARK',['../_i_rremote_int_8h.html#ae880d5d86be839ec77153ea58f1fb8be',1,'IRremoteInt.h']]],
  ['jvc_5fhdr_5fspace_4',['JVC_HDR_SPACE',['../_i_rremote_int_8h.html#ad0e01881ce778482d386270797f2a356',1,'IRremoteInt.h']]],
  ['jvc_5fone_5fspace_5',['JVC_ONE_SPACE',['../_i_rremote_int_8h.html#ac66f4778d06e0a5eda29695f4a0ad9fa',1,'IRremoteInt.h']]],
  ['jvc_5frpt_5flength_6',['JVC_RPT_LENGTH',['../_i_rremote_int_8h.html#a4077427ac6f70120351583eb4dde0663',1,'IRremoteInt.h']]],
  ['jvc_5fzero_5fspace_7',['JVC_ZERO_SPACE',['../_i_rremote_int_8h.html#a3e161d70fe56f2ed0f76b5421fd5b1b3',1,'IRremoteInt.h']]]
];
