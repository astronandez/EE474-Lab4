var searchData=
[
  ['rawbuf_0',['rawbuf',['../classdecode__results.html#a78d3244122456d52a493ef0c116fc7bb',1,'decode_results::rawbuf()'],['../structirparams__t.html#a39b3006fe9d26cc23c0feb639d3d793e',1,'irparams_t::rawbuf()']]],
  ['rawlen_1',['rawlen',['../classdecode__results.html#a434962fbdf5929ec4fa8f28fa443a4b5',1,'decode_results::rawlen()'],['../structirparams__t.html#a9667efc63148298657283a16f963d1ec',1,'irparams_t::rawlen()']]],
  ['rcvstate_2',['rcvstate',['../structirparams__t.html#a63354788dab4569f4092cd05e77f0260',1,'irparams_t']]],
  ['recvpin_3',['recvpin',['../structirparams__t.html#a50da5aa1c42a69b01d50ea688db67d14',1,'irparams_t']]]
];
