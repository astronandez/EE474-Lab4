var searchData=
[
  ['virtual_0',['VIRTUAL',['../_i_rremote_8h.html#a6dd04ec3fff7c731cc71d6796699d902',1,'IRremote.h']]]
];
