var searchData=
[
  ['ticks_5fhigh_0',['TICKS_HIGH',['../_i_rremote_int_8h.html#ac0d006cd9c029a2e6c4bd513ee5e7951',1,'IRremoteInt.h']]],
  ['ticks_5flow_1',['TICKS_LOW',['../_i_rremote_int_8h.html#a92632ec97aa1c7a60a990811744a6902',1,'IRremoteInt.h']]],
  ['timer_5fconfig_5fkhz_2',['TIMER_CONFIG_KHZ',['../_i_rremote_int_8h.html#a3ae43330f23d64b7b556165982034040',1,'IRremoteInt.h']]],
  ['timer_5fconfig_5fnormal_3',['TIMER_CONFIG_NORMAL',['../_i_rremote_int_8h.html#a9e4021c5656ed3fdd0ec6a58ab9ef0c5',1,'IRremoteInt.h']]],
  ['timer_5fcount_5ftop_4',['TIMER_COUNT_TOP',['../_i_rremote_int_8h.html#a5abc7b3b0d80e028e821c0843c184723',1,'IRremoteInt.h']]],
  ['timer_5fdisable_5fintr_5',['TIMER_DISABLE_INTR',['../_i_rremote_int_8h.html#a61c03dba74edfd4172e628a24b0aa6fb',1,'IRremoteInt.h']]],
  ['timer_5fdisable_5fpwm_6',['TIMER_DISABLE_PWM',['../_i_rremote_int_8h.html#a47b4fedbcb1d6009f98c1c0aac8db543',1,'IRremoteInt.h']]],
  ['timer_5fenable_5fintr_7',['TIMER_ENABLE_INTR',['../_i_rremote_int_8h.html#a48620ce9fc7fac57a6ccac069bad37ed',1,'IRremoteInt.h']]],
  ['timer_5fenable_5fpwm_8',['TIMER_ENABLE_PWM',['../_i_rremote_int_8h.html#a68f14dcdf1606930995e844b01a4763b',1,'IRremoteInt.h']]],
  ['timer_5fintr_5fname_9',['TIMER_INTR_NAME',['../_i_rremote_int_8h.html#a7c2448c6431d83ee924446bc7386f5d5',1,'IRremoteInt.h']]],
  ['timer_5fpwm_5fpin_10',['TIMER_PWM_PIN',['../_i_rremote_int_8h.html#a6a66ad6f42165bbf5849bd8809025743',1,'IRremoteInt.h']]],
  ['timer_5freset_11',['TIMER_RESET',['../_i_rremote_int_8h.html#a892a0fbd1ea794e5c6dbbc66e9703bd6',1,'IRremoteInt.h']]],
  ['tolerance_12',['TOLERANCE',['../_i_rremote_int_8h.html#a30c17564229ec2e37dfea9c6c9ad643e',1,'IRremoteInt.h']]],
  ['topbit_13',['TOPBIT',['../_i_rremote_int_8h.html#a118ad552670dbefa1df0ba72d147f5e1',1,'IRremoteInt.h']]]
];
