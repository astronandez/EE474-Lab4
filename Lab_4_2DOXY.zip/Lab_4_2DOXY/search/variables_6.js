var searchData=
[
  ['timer_0',['timer',['../structirparams__t.html#a69a8a586d1f9e27418d60b0032c92daf',1,'irparams_t']]]
];
