var searchData=
[
  ['rawbuf_0',['rawbuf',['../classdecode__results.html#a78d3244122456d52a493ef0c116fc7bb',1,'decode_results::rawbuf()'],['../structirparams__t.html#a39b3006fe9d26cc23c0feb639d3d793e',1,'irparams_t::rawbuf()']]],
  ['rawbuf_1',['RAWBUF',['../_i_rremote_8h.html#abb919079668bcc14433d4c857ab8a196',1,'IRremote.h']]],
  ['rawlen_2',['rawlen',['../classdecode__results.html#a434962fbdf5929ec4fa8f28fa443a4b5',1,'decode_results::rawlen()'],['../structirparams__t.html#a9667efc63148298657283a16f963d1ec',1,'irparams_t::rawlen()']]],
  ['rc5_3',['RC5',['../_i_rremote_8h.html#a91697bfec209fb3146fde1f40e425ede',1,'IRremote.h']]],
  ['rc5_5frpt_5flength_4',['RC5_RPT_LENGTH',['../_i_rremote_int_8h.html#aa8c287a3a1602657fde8f7bc6741bf1f',1,'IRremoteInt.h']]],
  ['rc5_5ft1_5',['RC5_T1',['../_i_rremote_int_8h.html#aacadad5996114b73e6ebe4ac4a3670f8',1,'IRremoteInt.h']]],
  ['rc6_6',['RC6',['../_i_rremote_8h.html#a259ca3c51823b7454fb93db646b81bb1',1,'IRremote.h']]],
  ['rc6_5fhdr_5fmark_7',['RC6_HDR_MARK',['../_i_rremote_int_8h.html#aaf18416e602d4df98ade887edd350ae7',1,'IRremoteInt.h']]],
  ['rc6_5fhdr_5fspace_8',['RC6_HDR_SPACE',['../_i_rremote_int_8h.html#a1f9724085ece5ed0103b5ce5e57b7aff',1,'IRremoteInt.h']]],
  ['rc6_5frpt_5flength_9',['RC6_RPT_LENGTH',['../_i_rremote_int_8h.html#ab20744e40f55c70de7fd11c163643d03',1,'IRremoteInt.h']]],
  ['rc6_5ft1_10',['RC6_T1',['../_i_rremote_int_8h.html#a6c695681ce7b028d11ae6af423b96178',1,'IRremoteInt.h']]],
  ['rcvstate_11',['rcvstate',['../structirparams__t.html#a63354788dab4569f4092cd05e77f0260',1,'irparams_t']]],
  ['recvpin_12',['recvpin',['../structirparams__t.html#a50da5aa1c42a69b01d50ea688db67d14',1,'irparams_t']]],
  ['repeat_13',['REPEAT',['../_i_rremote_8h.html#a2c9384c67919c632913b8db2088f8341',1,'IRremote.h']]],
  ['resume_14',['resume',['../class_i_rrecv.html#af40f1e16b1cc911e47ac3f0a9b3b1ec5',1,'IRrecv']]]
];
