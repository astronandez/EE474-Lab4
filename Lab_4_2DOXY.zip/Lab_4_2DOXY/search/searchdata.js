var indexSectionsWithContent =
{
  0: "_bcdegijlmnprstuvxy",
  1: "di",
  2: "ip",
  3: "bdeilmrst",
  4: "bdiprstvxy",
  5: "_bcdegijlmnprstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

