var searchData=
[
  ['irmessage_0',['IRmessage',['../_project_main_8ino_8ino.html#a60dd297f3e7867b920a5dc5dd743e324',1,'ProjectMain.ino.ino']]],
  ['irparams_1',['irparams',['../_i_rremote_int_8h.html#a5620be27a7445f25d43dbe3432ed6fd1',1,'IRremoteInt.h']]],
  ['irrecv_2',['irrecv',['../_project_main_8ino_8ino.html#a84028531ed04b53428dc49192477e313',1,'ProjectMain.ino.ino']]]
];
