var searchData=
[
  ['irparams_5ft_0',['irparams_t',['../structirparams__t.html',1,'']]],
  ['irrecv_1',['IRrecv',['../class_i_rrecv.html',1,'']]],
  ['irsend_2',['IRsend',['../class_i_rsend.html',1,'']]]
];
