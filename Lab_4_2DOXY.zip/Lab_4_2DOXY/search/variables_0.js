var searchData=
[
  ['bits_0',['bits',['../classdecode__results.html#ab083e0543bb3995339eda4609ad5743f',1,'decode_results']]],
  ['blinkflag_1',['blinkflag',['../structirparams__t.html#a7b900474e1aa7d2652b77b481c44e686',1,'irparams_t']]],
  ['brightness_2',['brightness',['../_project_main_8ino_8ino.html#aa7ab72a18faba1d13601a9209ff2dcf8',1,'ProjectMain.ino.ino']]]
];
