var searchData=
[
  ['sharpaddress_0',['sharpAddress',['../classdecode__results.html#a58646241154c6f0a47083ce67e7327fb',1,'decode_results']]],
  ['step_5fdelay_1',['step_delay',['../_project_main_8ino_8ino.html#a894ec8ef660a1c05b7f3c23e29f83b6b',1,'ProjectMain.ino.ino']]]
];
