var searchData=
[
  ['gap_5fticks_0',['GAP_TICKS',['../_i_rremote_int_8h.html#a9d8275bffb8c217b07a58518b03ad3e3',1,'IRremoteInt.h']]]
];
