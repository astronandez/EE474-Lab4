var searchData=
[
  ['value_0',['value',['../classdecode__results.html#aba6924fbb6aae401a54f63b4032700d5',1,'decode_results']]],
  ['virtual_1',['VIRTUAL',['../_i_rremote_8h.html#a6dd04ec3fff7c731cc71d6796699d902',1,'IRremote.h']]]
];
